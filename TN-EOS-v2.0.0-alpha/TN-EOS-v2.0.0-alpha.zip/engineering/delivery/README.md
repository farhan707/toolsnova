Delivery folder.
