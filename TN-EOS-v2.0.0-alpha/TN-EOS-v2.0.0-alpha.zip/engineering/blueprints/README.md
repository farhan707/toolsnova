Blueprints folder.
